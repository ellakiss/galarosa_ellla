
<Project-Information>
	 This repository is for Activity 2-3 in Web Systems and Technologies. <br>
   This repo implements a basic or flat folder structure in Music Website Design <br> <br>
	 Group Members:

-  Christopher James Sayson
-  Michael N. Lonceras
-  Valerie Soreda
-  John Russel Soreda
  
</Project-Information>

